<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Dashboard Pegawai - Mazer Professional</title>
    
    <link rel="shortcut icon" href="assets/compiled/png/favicon.png" type="image/x-icon">
    <link rel="stylesheet" crossorigin href="./assets/compiled/css/app.css">
    <link rel="stylesheet" crossorigin href="./assets/compiled/css/app-dark.css">
    <link rel="stylesheet" crossorigin href="./assets/compiled/css/iconly.css">
    <link rel="stylesheet" href="assets/extensions/simple-datatables/style.css">
    <link rel="stylesheet" crossorigin href="assets/compiled/css/table-datatable.css">
    
    <script src="https://cdn.jsdelivr.net/npm/sweetalert2@11"></script>
</head>

<body>
    <script src="assets/static/js/initTheme.js"></script>
    <div id="app">
        <div id="sidebar">
            <div class="sidebar-wrapper active">
                <div class="sidebar-header position-relative">
                    <div class="d-flex justify-content-between align-items-center">
                        <div class="logo">
                            <a href="index.php"><img src="assets/compiled/svg/logo.svg" alt="Logo"></a>
                        </div>
                    </div>
                </div>
                <div class="sidebar-menu">
                    <ul class="menu">
                        <li class="sidebar-title">Menu Utama</li>
                        <li class="sidebar-item active">
                            <a href="index.php" class='sidebar-link'>
                                <i class="bi bi-grid-fill"></i>
                                <span>Dashboard</span>
                            </a>
                        </li>
                        <li class="sidebar-title">Authentication</li>
                        <li class="sidebar-item has-sub">
                            <a href="#" class='sidebar-link'><i class="bi bi-person-badge-fill"></i><span>Auth</span></a>
                            <ul class="submenu">
                                <li class="submenu-item"><a href="../inc/login.php" class="submenu-link">Login</a></li>
                            </ul>
                        </li>
                    </ul>
                </div>
            </div>
        </div>

        <div id="main">
            <header class="mb-3">
                <a href="#" class="burger-btn d-block d-xl-none"><i class="bi bi-justify fs-3"></i></a>
            </header>
            
            <div id="content" class="main-content">
                <div class="container">
                    
                    <div class="page-title mb-4">
                        <h3>Dashboard Pegawai</h3>
                        <p class="text-subtitle text-muted">Ringkasan data perusahaan anda.</p>
                    </div>
                    <div class="row">
                        <div class="col-6 col-lg-3 col-md-6">
                            <div class="card">
                                <div class="card-body px-4 py-4-5">
                                    <div class="d-flex align-items-center">
                                        <div class="stats-icon purple mb-2"><i class="iconly-boldProfile"></i></div>
                                        <div class="ms-3">
                                            <h6 class="text-muted font-semibold">Total Pegawai</h6>
                                            <h6 class="font-extrabold mb-0">1.250</h6>
                                        </div>
                                    </div>
                                </div>
                            </div>
                        </div>
                        </div>

                    <section class="section mt-4">
                        <div class="card">
                            <div class="card-header d-flex justify-content-between align-items-center">
                                <h5 class="card-title">Daftar Pegawai Aktif</h5>
                                <button type="button" class="btn btn-primary" data-bs-toggle="modal" data-bs-target="#modalTambah">
                                    <i class="bi bi-plus-circle"></i> Tambah Pegawai
                                </button>
                            </div>
                            <div class="card-body">
                                <table class="table table-striped" id="table1">
                                    <thead>
                                        <tr>
                                            <th>Nama</th>
                                            <th>Email</th>
                                            <th>Status</th>
                                            <th>Aksi</th>
                                        </tr>
                                    </thead>
                                    <tbody>
                                        <tr>
                                            <td>Graiden</td>
                                            <td>graiden@mail.com</td>
                                            <td><span class="badge bg-success">Active</span></td>
                                            <td>
                                                <button onclick="pesanHapus()" class="btn btn-sm btn-danger"><i class="bi bi-trash"></i></button>
                                            </td>
                                        </tr>
                                    </tbody>
                                </table>
                            </div>
                        </div>
                    </section>
                </div>
            </div>

            <div class="modal fade" id="modalTambah" tabindex="-1" aria-labelledby="modalTambahLabel" aria-hidden="true">
                <div class="modal-dialog modal-dialog-centered">
                    <div class="modal-content">
                        <div class="modal-header bg-primary">
                            <h5 class="modal-title white" id="modalTambahLabel">Form Tambah Pegawai</h5>
                            <button type="button" class="btn-close" data-bs-dismiss="modal" aria-label="Close"></button>
                        </div>
                        <form id="formTambah">
                            <div class="modal-body">
                                <div class="form-group mb-3">
                                    <label>Nama Lengkap</label>
                                    <input type="text" class="form-control" placeholder="Masukkan Nama" required>
                                </div>
                                <div class="form-group mb-3">
                                    <label>Email</label>
                                    <input type="email" class="form-control" placeholder="Email@mail.com" required>
                                </div>
                            </div>
                            <div class="modal-footer">
                                <button type="button" class="btn btn-light-secondary" data-bs-dismiss="modal">Batal</button>
                                <button type="button" onclick="simpanData()" class="btn btn-primary">Simpan Data</button>
                            </div>
                        </form>
                    </div>
                </div>
            </div>

            <footer>
                <div class="footer clearfix mb-0 text-muted">
                    <div class="float-start"><p>2023 &copy; Mazer</p></div>
                </div>
            </footer>
        </div>
    </div>

    <script src="assets/static/js/components/dark.js"></script>
    <script src="assets/extensions/perfect-scrollbar/perfect-scrollbar.min.js"></script>
    <script src="assets/compiled/js/app.js"></script>
    <script src="assets/extensions/simple-datatables/umd/simple-datatables.js"></script>

    <script>
        // Inisialisasi Tabel
        let dataTable = new simpleDatatables.DataTable(document.querySelector('#table1'));

        // Fungsi Simpan (Contoh Pop-up Pesan Sukses)
        function simpanData() {
            // Menutup Modal
            var myModalEl = document.getElementById('modalTambah');
            var modal = bootstrap.Modal.getInstance(myModalEl);
            modal.hide();

            // Menampilkan Pop-up SweetAlert2
            Swal.fire({
                title: "Berhasil!",
                text: "Data pegawai baru telah ditambahkan.",
                icon: "success",
                confirmButtonColor: "#435ebe"
            });
        }

        // Fungsi Hapus (Contoh Pop-up Pesan Konfirmasi)
        function pesanHapus() {
            Swal.fire({
                title: "Apakah anda yakin?",
                text: "Data yang dihapus tidak bisa kembali!",
                icon: "warning",
                showCancelButton: true,
                confirmButtonColor: "#dc3545",
                cancelButtonColor: "#6c757d",
                confirmButtonText: "Ya, Hapus!"
            }).then((result) => {
                if (result.isConfirmed) {
                    Swal.fire("Terhapus!", "Data telah dihapus.", "success");
                }
            });
        }
    </script>
</body>
</html>